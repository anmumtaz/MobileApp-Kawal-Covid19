package com.example.kawalcovid_19.activity

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.annotation.NonNull
import com.example.kawalcovid_19.R
import com.example.kawalcovid_19.api.RetrofitClient
import com.example.kawalcovid_19.model.ResponIndonesia
import com.google.android.material.bottomnavigation.BottomNavigationView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        showIndonesia()

        val btnSelengkapnya: Button = findViewById(R.id.selengkapnya)
        btnSelengkapnya.setOnClickListener(this)

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_nav)
        bottomNavigationView.setSelectedItemId(R.id.home)
        bottomNavigationView.setOnNavigationItemSelectedListener(object:
            BottomNavigationView.OnNavigationItemSelectedListener {
            override fun onNavigationItemSelected(@NonNull menuItem: MenuItem):Boolean {
                when (menuItem.getItemId()) {
                    R.id.provinsi_menu -> {
                        startActivity(Intent(this@MainActivity, ProvinceActivity::class.java))
                        overridePendingTransition(0, 0)
                        return true
                    }
                    R.id.pemetaan_menu -> {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://covid19.go.id/peta-sebaran")))
                        overridePendingTransition(0, 0)
                        return true
                    }
                    R.id.about_menu -> {
                        startActivity(Intent(this@MainActivity, AboutUsActivity::class.java))
                        overridePendingTransition(0, 0)
                        return true
                    }
                }
                return false
            }
        })
    }
    private fun showIndonesia() {
        RetrofitClient.instance.getIndonesia().enqueue(object: Callback<ArrayList<ResponIndonesia>>{
            override fun onFailure(call: Call<ArrayList<ResponIndonesia>>, t: Throwable) {
                Toast.makeText(this@MainActivity,"$(t.message)", Toast.LENGTH_SHORT).show()
            }

            override fun onResponse(
                call: Call<ArrayList<ResponIndonesia>>,
                response: Response<ArrayList<ResponIndonesia>>
            ) {
                val Indonesia = response.body()?.get(0)
                val positive = Indonesia?.positif
                val hospitalize = Indonesia?.dirawat
                val recovered = Indonesia?.sembuh
                val death = Indonesia?.meninggal

                tvpositif.text = positive
                tvdirawat.text = hospitalize
                tvsembuh.text = recovered
                tvmeninggal.text = death
            }

        })
    }
    override fun onClick(v: View) {
        when (v.id) {
            R.id.selengkapnya -> {
                val moveIntent = Intent(this@MainActivity, MoreActivity::class.java)
                startActivity(moveIntent)

            }
        }
    }
}