package com.example.kawalcovid_19.model

data class ResponIndonesia(
    val name : String,
    val positif : String,
    val sembuh : String,
    val dirawat : String,
    val meninggal : String
)