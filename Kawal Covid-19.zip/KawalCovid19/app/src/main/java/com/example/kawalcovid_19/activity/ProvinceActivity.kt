package com.example.kawalcovid_19.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kawalcovid_19.R
import com.example.kawalcovid_19.adapter.ProvinceAdapter
import com.example.kawalcovid_19.api.RetrofitClient
import com.example.kawalcovid_19.model.ResponProvinsi
import kotlinx.android.synthetic.main.activity_province.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProvinceActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_province)
        showProvince()
    }

    private fun showProvince() {
        rvprovince.setHasFixedSize(true)
        rvprovince.layoutManager = LinearLayoutManager(this)

        RetrofitClient.instance.getProvinsi().enqueue(object: Callback<ArrayList<ResponProvinsi>>{
            override fun onFailure(call: Call<ArrayList<ResponProvinsi>>, t: Throwable) {
                Toast.makeText(this@ProvinceActivity, "${t.message}", Toast.LENGTH_SHORT).show()
            }

            override fun onResponse(
                call: Call<ArrayList<ResponProvinsi>>,
                response: Response<ArrayList<ResponProvinsi>>
            ) {
                val list = response.body()
                val adapter = list?.let { ProvinceAdapter(it) }
                rvprovince.adapter = adapter
            }

        })

        }
    }