package com.example.kawalcovid_19.model

data class ResponProvinsi(
    val attributes : Provinsi
)