package com.example.kawalcovid_19.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.kawalcovid_19.R
import com.example.kawalcovid_19.model.ResponProvinsi
import kotlinx.android.synthetic.main.item_province.view.*

class ProvinceAdapter (private val list : ArrayList<ResponProvinsi>): RecyclerView.Adapter<ProvinceAdapter.ProvinceViewHolder>() {
    inner class ProvinceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(province: ResponProvinsi) {
            with(itemView) {
                tvname.text = province.attributes.province
                tvpositive.text = province.attributes.positive.toString()
                tvrecover.text = province.attributes.recovered.toString()
                tvdeath.text = province.attributes.death.toString()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProvinceViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_province, parent, false)
        return ProvinceViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProvinceAdapter.ProvinceViewHolder, position: Int) {
        holder.bind(list[position])
    }

    override fun getItemCount(): Int = list.size
    }