package com.example.kawalcovid_19.api

import com.example.kawalcovid_19.model.ResponIndonesia
import com.example.kawalcovid_19.model.ResponProvinsi
import retrofit2.Call
import retrofit2.http.GET

interface Api {
    @GET("indonesia")
    fun getIndonesia(): Call<ArrayList<ResponIndonesia>>

    @GET("indonesia/provinsi")
    fun getProvinsi(): Call<ArrayList<ResponProvinsi>>
}